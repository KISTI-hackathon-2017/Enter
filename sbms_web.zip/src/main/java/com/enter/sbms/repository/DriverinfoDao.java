package com.enter.sbms.repository;

import org.springframework.stereotype.Service;

@Service
public class DriverinfoDao {

}
