package com.enter.sbms.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BusinfoDao {

}
