package com.example.bit_user.sbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import adapter.ListViewAdapter;
import items.ListViewItem;

public class BusStopInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_stop_info);

        ListView listview;
        ListViewAdapter adapter;

        // Adapter 생성
        adapter = new ListViewAdapter();

        // 리스트뷰 참조 및 Adapter달기
        listview = (ListView) findViewById(R.id.bus);
        listview.setAdapter(adapter);

        // 첫 번째 아이템 추가.
        adapter.addItem("M7412", 24, 45, 5);
        // 두 번째 아이템 추가.
        adapter.addItem("441", 10, 30, 12);
        // 세 번째 아이템 추가.
        adapter.addItem("341", 30, 40, 1);
        // 네 번째 아이템 추가.
        adapter.addItem("9700", 41, 45, 13);
        adapter.addItem("470", 20, 40, 8);
        adapter.addItem("471", 17, 40, 5);
        adapter.addItem("140", 9, 40, 30);
        adapter.addItem("420", 29, 30, 20);
        adapter.addItem("405", 27, 30, 7);
        adapter.addItem("4421", 3, 30, 6);
        adapter.addItem("M7462", 32, 45, 0);
        adapter.addItem("651", 10, 45, 6);
        adapter.addItem("750", 5, 45, 13);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // get item

                /*String titleStr = item.getTitle() ;
                String descStr = item.getDesc() ;
                Drawable iconDrawable = item.getIcon() ;*/

                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position) ;

                Intent intent = new Intent(BusStopInfoActivity.this, BusInfoActivity.class);
                intent.putExtra("busNum", item.getBus_num() + "");
                startActivity(intent);
            }
        });
    }
}
