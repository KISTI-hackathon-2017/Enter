package com.example.bit_user.sbms;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/**
 * Created by bit-user on 2017-11-18.
 */

public class ColorView extends View {
    public ColorView(Context context) {
        super(context);
    }

    @Override protected void onDraw(Canvas c) {
        // 원하는 그림을 그려주는 부분
        Paint pnt = new Paint();
        for (int x = 0; x < 1024; x += 4) {
            // 뷰의 너비는 1024px이 되므로 일반적인 스마트폰의 너비를 초과한다.
            pnt.setARGB(255, 255 - x / 4, 255 - x / 4, 255);
            c.drawRect(x, 0, x + 4, 200, pnt); c.drawLine(0, 0, getWidth(), 400, pnt);
            // 해당 라인은 뷰의 높이인 200을 넘어가면 // 보이지 않는다.
        }
    }

    @Override protected void onMeasure(int wMS, int hMS) {
        // 뷰의 사이즈를 지정한다.
        // 1024 사이즈만큼 스크롤이 가능해진다.
        setMeasuredDimension(1024, 200);
    }
}
