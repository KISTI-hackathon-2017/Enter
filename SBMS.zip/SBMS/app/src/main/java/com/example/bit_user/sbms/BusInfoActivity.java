package com.example.bit_user.sbms;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import adapter.ListViewAdapter;
import adapter.RealTimeAdapter;
import items.ListViewItem;
import items.RealTimeItem;

public class BusInfoActivity extends AppCompatActivity {
    private View layoutGraphView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_info);

        ListView listview;
        RealTimeAdapter adapter;

        // Adapter 생성
        adapter = new RealTimeAdapter();

        // 리스트뷰 참조 및 Adapter달기
        listview = (ListView) findViewById(R.id.real_list);
        listview.setAdapter(adapter);

        // 첫 번째 아이템 추가.
        adapter.addItem("속도", "30km/h");
        adapter.addItem("실내온도", "30°C");
        adapter.addItem("습도", "50%");
        adapter.addItem("좌석수", "30 / 45");
        adapter.addItem("ETC", "ETC");
        adapter.addItem("ETC", "ETC");
        adapter.addItem("ETC", "ETC");
        adapter.addItem("ETC", "ETC");
        adapter.addItem("ETC", "ETC");
        adapter.addItem("ETC", "ETC");

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                RealTimeItem item = (RealTimeItem) parent.getItemAtPosition(position) ;

                Toast.makeText(getApplicationContext(), item.getKey() + " : " + item.getValue(), Toast.LENGTH_SHORT).show();
            }
        });

        Button btn_detail = (Button) findViewById(R.id.btn_detail);
        btn_detail.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                startActivity(new Intent(BusInfoActivity.this, BusDetailActivity.class));
            }
        });

        // 그래프 추가
        HorizontalScrollView scr = (HorizontalScrollView) findViewById(R.id.scr);

        Button btn_complain = (Button) findViewById(R.id.btn_complain);
        btn_complain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "소중한 의견 감사합니다.", Toast.LENGTH_SHORT).show();
//                Snackbar.make(view, "소중한 의견 감사합니다.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                startActivity(new Intent(BusInfoActivity.this, ComplainActivity.class));
            }
        });

        TextView tv_score = (TextView) findViewById(R.id.driver_score);
        tv_score.setTextColor(Color.parseColor("#FDDD00"));
    }
}




