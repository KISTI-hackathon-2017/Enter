package com.example.bit_user.sbms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import adapter.DetailAdapter;
import items.DetailItem;

public class BusDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_detail);

        ListView listview ;
        DetailAdapter adapter;

        // Adapter 생성
        adapter = new DetailAdapter() ;

        // 리스트뷰 참조 및 Adapter달기
        listview = (ListView) findViewById(R.id.detail);
        listview.setAdapter(adapter);

        //데이터를 저장하게 되는 리스트
        List<String> list = new ArrayList<>();
        adapter.addItem("최근 점검일", "2017-10-25");
        adapter.addItem("타이어 상태", "양호");
        adapter.addItem("엔진 상태", "양호");
        adapter.addItem("라이트", "양호");
        adapter.addItem("브레이크 상태", "보통");
        adapter.addItem("온,냉방기", "양호");
        adapter.addItem("기타부품", "양호");
        adapter.addItem("청결도", "불량");

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DetailItem item = (DetailItem) parent.getItemAtPosition(position);

                Toast.makeText(getApplicationContext(), item.getKey() + " : " + item.getValue(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
